import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* Add your Next.js config here */
};

export default nextConfig;
